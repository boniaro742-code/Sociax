@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.sociax.app.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.sociax.app.data.*
import com.sociax.app.ui.theme.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** One ad page of the Short Video feed (Step 41). */
class AdSlot(val id: Long, val afterVideoId: Long, val ad: LoadedAd)

/** A page of the Short Video pager: an ordinary video or an ad. */
sealed interface FeedSlot {
    val key: String
    class Video(val item: ShortVideo) : FeedSlot { override val key = "v${item.id}" }
    class Ad(val slot: AdSlot) : FeedSlot { override val key = "a${slot.id}" }
}

/** Holds the Short Video feed so it survives opening comments / creating a video and coming back. */
class ShortsState {
    val items = mutableStateListOf<ShortVideo>()
    var loaded by mutableStateOf(false)
    var endReached by mutableStateOf(false)
    var page by mutableIntStateOf(0)
    var cursor: String? = null      // Step 40: where the ranked For You list continues (null = start)
    var ranked = true               // false = the server answered newest-first, so paging continues with "before"

    // Step 41 (plan v3.8 section 28): ad pages between ordinary videos. An ad page sits right AFTER the video it is anchored to.
    val adSlots = mutableStateListOf<AdSlot>()
    val seenSinceAd = HashSet<Long>()   // ordinary videos looked at since the last ad page (never two ad pages in a row)
    var nextGap = 3                     // how many ordinary videos before the next ad (3 or 4, varied)
    private var adCounter = 0L

    // Step 75 (plan v4.0.1): used by the full-screen player that opens from a Home video (and ignored by the Short Video tab)
    val unavailable = mutableStateListOf<Long>()      // videos found deleted / hidden / no longer allowed: the page says so and plays nothing
    val hiddenCreators = HashSet<String>()            // "Hide creator" done in that player: Home applies it when the person comes back

    fun reset() { items.clear(); loaded = false; endReached = false; page = 0; cursor = null; ranked = true; unavailable.clear(); hiddenCreators.clear(); clearAds() }

    /** The pages of the pager in order: video, video, video, [ad], video ... Ads whose anchor video is gone are ignored. */
    fun slots(): List<FeedSlot> = buildList {
        for (v in items) {
            add(FeedSlot.Video(v))
            adSlots.firstOrNull { it.afterVideoId == v.id }?.let { add(FeedSlot.Ad(it)) }
        }
    }

    fun addAd(afterVideoId: Long, ad: LoadedAd) { adSlots.add(AdSlot(++adCounter, afterVideoId, ad)) }

    fun clearAds() { adSlots.clear(); seenSinceAd.clear(); nextGap = 3 }

    /** Ads are no longer allowed (Pro, cap reached): remove the ad pages the person has not seen yet. [keepAfter] = the one on screen. */
    fun dropUnseenAds(keepAfter: Long?) {
        val gone = adSlots.filter { !it.ad.impressed && it.afterVideoId != keepAfter }
        adSlots.removeAll(gone.toSet())
    }

    fun replace(id: Long, f: (ShortVideo) -> ShortVideo) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) items[i] = f(items[i])
    }
}

private fun msg(e: Exception) =
    if (e is ApiException) e.message ?: "Something went wrong" else "Cannot reach the Sociax server."

// =====================================================================
// Short Video tab: full-screen vertical feed (swipe up / down)
// =====================================================================
@Composable
fun ShortVideoScreen(
    api: ApiClient, state: ShortsState, ads: AdsController, onCreate: () -> Unit, onComments: (ShortVideo) -> Unit,
    onBack: () -> Unit = {}, onSearch: () -> Unit = {},
    // Step 75 (plan v4.0.1): set ONLY when this screen is the full-screen player opened from a Home video. It then has a Back arrow instead of
    // "+" / refresh / search, no tab bar below, and a tap on the creator opens the profile. The Short Video tab passes neither.
    onClose: (() -> Unit)? = null, onOpenProfile: ((String) -> Unit)? = null
) {
    val viewer = onClose != null
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val scope = rememberCoroutineScope()
    val prefs = remember { Prefs(context) }
    var loading by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    val reportThanks = tr("report_thanks")

    suspend fun loadMore() {
        if (loading || state.endReached) return
        loading = true
        try {
            if (state.ranked) {
                val r = api.shortsForYou(state.cursor)
                state.cursor = r.nextCursor
                if (!r.ranked) state.ranked = false
                state.items.addAll(r.items.filter { n -> state.items.none { it.id == n.id } })
                if (if (r.ranked) r.nextCursor == null else r.items.size < 10) state.endReached = true
            } else {
                val page = api.shortsFeed(state.items.lastOrNull()?.id)
                state.items.addAll(page.filter { n -> state.items.none { it.id == n.id } })
                if (page.size < 10) state.endReached = true
            }
            state.loaded = true; notice = null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            notice = if (e is ApiException) e.message else "Cannot reach the Sociax server. Is the backend running?"
        }
        loading = false
    }

    LaunchedEffect(state.loaded) { if (!state.loaded) loadMore() }

    // Step 41: the SERVER decides whether this account may see ads (Free, cap not reached). Unknown = no ads. Pro = the SDK never starts.
    // MainActivity asks it each time this tab is on screen; here it is asked again when the app comes back to the front.
    val lifeOwner = LocalLifecycleOwner.current
    DisposableEffect(lifeOwner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME && ads.statusIsStale()) scope.launch { ads.refresh(activity) }
        }
        lifeOwner.lifecycle.addObserver(obs)
        onDispose { lifeOwner.lifecycle.removeObserver(obs) }
    }

    fun toggleLike(s: ShortVideo) {
        val on = !s.liked
        state.replace(s.id) { it.copy(liked = on, likeCount = it.likeCount + if (on) 1 else -1) }
        scope.launch {
            try { api.setShortLike(s.id, on) } catch (e: CancellationException) { throw e } catch (e: Exception) {
                state.replace(s.id) { it.copy(liked = !on, likeCount = it.likeCount + if (on) -1 else 1) }
                notice = msg(e)
            }
        }
    }

    fun toggleReaction(s: ShortVideo, kind: String) {
        val now = s.reactions[kind] ?: React()
        val on = !now.mine
        fun setReact(mine: Boolean, count: Int) = state.replace(s.id) {
            it.copy(reactions = it.reactions + (kind to React(count.coerceAtLeast(0), mine)))
        }
        setReact(on, now.count + if (on) 1 else -1)
        scope.launch {
            try { api.setShortReaction(s.id, kind, on) } catch (e: CancellationException) { throw e } catch (e: Exception) {
                setReact(now.mine, now.count); notice = msg(e)
            }
        }
    }

    fun toggleSave(s: ShortVideo) {
        val on = !s.saved
        state.replace(s.id) { it.copy(saved = on, saveCount = (it.saveCount + if (on) 1 else -1).coerceAtLeast(0)) }
        scope.launch {
            try { api.setShortBookmark(s.id, on) } catch (e: CancellationException) { throw e } catch (e: Exception) {
                state.replace(s.id) { it.copy(saved = !on, saveCount = (it.saveCount + if (on) -1 else 1).coerceAtLeast(0)) }
                notice = msg(e)
            }
        }
    }

    fun toggleFollow(s: ShortVideo) {
        val follow = s.followStatus == "none"
        scope.launch {
            try {
                val status = api.setFollow(s.username, follow)
                state.items.indices.forEach { i ->
                    if (state.items[i].username == s.username) state.items[i] = state.items[i].copy(followStatus = status)
                }
            } catch (e: CancellationException) { throw e } catch (e: Exception) { notice = msg(e) }
        }
    }

    fun delete(s: ShortVideo) {
        scope.launch {
            try { api.deleteShort(s.id); state.items.removeAll { it.id == s.id } }
            catch (e: CancellationException) { throw e } catch (e: Exception) { notice = msg(e) }
        }
    }

    fun report(s: ShortVideo, reason: String) {
        scope.launch {
            try { api.reportShort(s.id, reason); notice = reportThanks }
            catch (e: CancellationException) { throw e } catch (e: Exception) { notice = msg(e) }
        }
    }

    // Step 40: "Not interested" / "Hide creator" (plan v3.9 section 31.2). The video leaves the list at once.
    fun notInterested(s: ShortVideo) {
        scope.launch {
            try { api.recFeedback("not_interested", "short", s.id); state.items.removeAll { it.id == s.id } }
            catch (e: CancellationException) { throw e } catch (e: Exception) { notice = msg(e) }
        }
    }

    fun hideCreator(s: ShortVideo) {
        scope.launch {
            try { api.recFeedback("hide_creator", "short", s.id); state.hiddenCreators.add(s.username); state.items.removeAll { it.username == s.username } }
            catch (e: CancellationException) { throw e } catch (e: Exception) { notice = msg(e) }
        }
    }

    // The tab bar is below the Short Video tab; the Home player has none, so it only keeps clear of the system navigation bar.
    val clearance = if (viewer) WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 8.dp else bottomBarClearance()

    // Step 75 (plan v4.0.1 section 3): the video that was tapped, and the ones one swipe away, are asked of the SERVER again (same rules as the
    // feed: public / followers / private account / block / deleted / hidden) BEFORE they play. 404 = "not available": the page says so and
    // nothing is played or shown from it. A network failure does not block (the video was already allowed a moment ago).
    val checked = remember { HashSet<Long>() }
    val cleared = remember { mutableStateListOf<Long>() }      // checked and allowed: only these pages show a picture / play (Home player only)
    suspend fun verify(id: Long) {
        if (!checked.add(id) || id in state.unavailable) return
        try {
            val fresh = api.short(id)
            state.replace(id) { fresh }
            cleared.add(id)
        } catch (e: CancellationException) {
            checked.remove(id); throw e
        } catch (e: ApiException) {
            if (e.code == 404 || e.code == 403) state.unavailable.add(id)
            else { checked.remove(id); cleared.add(id) }       // the server could not be asked (e.g. error 500): not a reason to block
        } catch (e: Exception) {
            checked.remove(id); cleared.add(id)               // no network: the video was allowed a moment ago, so it is not blocked
        }
    }

    Box(Modifier.fillMaxSize().background(MediaBackdrop)) {
        if (state.items.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                if (loading) CircularProgressIndicator(color = Accent)
                else {
                    Text(notice ?: tr("no_shorts"),
                        color = Color.White.copy(.8f))
                    Spacer(Modifier.height(14.dp))
                    PillButton(tr("try_again"), { state.endReached = false; scope.launch { loadMore() } }, filled = false)
                }
            }
        } else {
            val pager = rememberPagerState(
                initialPage = state.page.coerceIn(0, (state.slots().size - 1).coerceAtLeast(0))
            ) { state.slots().size }
            if (viewer) LaunchedEffect(pager.currentPage, state.items.size) {
                val here = state.slots().getOrNull(pager.currentPage)
                val id = (here as? FeedSlot.Video)?.item?.id ?: return@LaunchedEffect
                verify(id)                                   // the opened video first, so a blocked one never plays
                val ids = state.items.map { it.id }
                val at = ids.indexOf(id)
                ids.getOrNull(at + 1)?.let { verify(it) }
                ids.getOrNull(at - 1)?.let { verify(it) }
            }
            LaunchedEffect(pager.currentPage) {
                state.page = pager.currentPage
                val slots = state.slots()
                val here = slots.getOrNull(pager.currentPage)
                val videoId = when (here) { is FeedSlot.Video -> here.item.id; is FeedSlot.Ad -> here.slot.afterVideoId; null -> null }
                val vIdx = state.items.indexOfFirst { it.id == videoId }
                if (vIdx < 0 || vIdx >= state.items.size - 3) loadMore()

                // Step 41: an ad page only AFTER about 3 ordinary videos (3 or 4, varied), never two in a row, never as the last page,
                // and only when the server said Free + under the daily cap and an ad is really loaded. No ad -> the feed just continues.
                if (here is FeedSlot.Video) {
                    state.seenSinceAd.add(here.item.id)
                    val nextIsAd = slots.getOrNull(pager.currentPage + 1) is FeedSlot.Ad
                    val hasNextVideo = vIdx in 0 until state.items.size - 1
                    if (state.seenSinceAd.size >= state.nextGap && !nextIsAd && hasNextVideo && ads.allowed) {
                        if (ads.statusIsStale()) ads.refresh(activity)          // re-check Free / cap with the server before placing
                        val loaded = if (ads.allowed) ads.take() else null
                        if (loaded != null) {
                            state.addAd(here.item.id, loaded)
                            state.seenSinceAd.clear()
                            val st = ads.status
                            val lo = st?.everyMin ?: 3
                            val hi = maxOf(st?.everyMax ?: 4, lo)
                            state.nextGap = kotlin.random.Random.nextInt(lo, hi + 1)
                        }
                    }
                    ads.ensureLoaded()
                }
            }
            // Pro bought / cap reached: ad pages not yet seen disappear at once (the one on screen stays until swiped)
            LaunchedEffect(ads.allowed) {
                if (!ads.allowed) {
                    val cur = state.slots().getOrNull(pager.currentPage)
                    state.dropUnseenAds((cur as? FeedSlot.Ad)?.slot?.afterVideoId)
                }
            }
            VerticalPager(pager, Modifier.fillMaxSize(), key = { state.slots().getOrNull(it)?.key ?: it }) { i ->
                when (val slot = state.slots().getOrNull(i)) {
                    null -> return@VerticalPager
                    is FeedSlot.Ad -> AdPage(slot.slot.ad, active = pager.currentPage == i, onSeen = { ads.markSeen(slot.slot.ad.key) })
                    is FeedSlot.Video -> {
                        val s = slot.item
                        ShortPage(
                            s, active = pager.currentPage == i, autoplay = prefs.autoplay, dataSaver = prefs.dataSaver,
                            clearance = clearance, blocked = s.id in state.unavailable,
                            holding = viewer && s.id !in cleared && s.id !in state.unavailable,
                            onProfile = onOpenProfile?.let { open -> { open(s.username) } },
                            onLike = { toggleLike(s) }, onComments = { onComments(s) }, onFollow = { toggleFollow(s) },
                            onReact = { toggleReaction(s, it) }, onSave = { toggleSave(s) },
                            onDelete = { delete(s) }, onReport = { report(s, it) },
                            onNotInterested = { notInterested(s) }, onHideCreator = { hideCreator(s) },
                            onImpression = { if (!s.mine) api.trackEvent("short", s.id, "impression", 1000) },
                            onShared = { if (!s.mine) api.trackEvent("short", s.id, "share") },
                            onWatched = { ms, done ->
                                // what really played: a clean "watch" (and "complete" near the end); a 1-3 s look and leave = "skip"
                                if (!s.mine) {
                                    if (ms >= 1000) api.trackEvent("short", s.id, "watch", ms)
                                    if (done) api.trackEvent("short", s.id, "complete", ms)
                                    else if (ms >= 1000 && ms < 3000) api.trackEvent("short", s.id, "skip", ms)
                                }
                            }
                        )
                    }
                }
            }
        }

        // top bar (new design): upload (+) on the left, "For you" with its underline in the middle, refresh and search on the right.
        // (Step 59: there is no "Following" tab: the server has no following-only feed for short videos, so none is shown.)
        Column(Modifier.fillMaxWidth().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (onClose != null) GlassIconButton(Icons.Filled.ArrowBack, tr("a11y_back"), onClose, size = 40, onMedia = true)   // Step 75: back to Home
                else GlassIconButton(Icons.Filled.Add, tr("a11y_upload_short"), onCreate, size = 40, onMedia = true)
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(tr("for_you"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Box(Modifier.padding(top = 4.dp).width(28.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(Color.White))
                }
                if (viewer) Spacer(Modifier.size(40.dp))      // keeps "For you" in the middle; no refresh / search here (they would lose the opened video)
                else {
                    GlassIconButton(Icons.Filled.Refresh, tr("a11y_refresh"), { state.reset() }, size = 40, onMedia = true)   // Step 40: a new ranking
                    Spacer(Modifier.width(8.dp))
                    GlassIconButton(Icons.Filled.Search, tr("search"), onSearch, size = 40, onMedia = true)
                }
            }
            notice?.takeIf { state.items.isNotEmpty() }?.let {
                Text(it, color = Color(0xFFFFB4A8), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
            }
        }
    }
}

@Composable
private fun ShortPage(
    s: ShortVideo, active: Boolean, autoplay: Boolean, dataSaver: Boolean, clearance: Dp, blocked: Boolean, holding: Boolean, onProfile: (() -> Unit)?,
    onLike: () -> Unit, onComments: () -> Unit, onFollow: () -> Unit,
    onReact: (String) -> Unit, onSave: () -> Unit, onDelete: () -> Unit, onReport: (String) -> Unit,
    onNotInterested: () -> Unit, onHideCreator: () -> Unit, onImpression: () -> Unit, onShared: () -> Unit,
    onWatched: (Long, Boolean) -> Unit
) {
    val context = LocalContext.current
    LaunchedEffect(s.id, active, blocked, holding) { if (active && !blocked && !holding) { delay(1000); onImpression() } }      // Step 40: seen = 1 s as the current video
    var paused by remember(s.id) { mutableStateOf(false) }
    var startedByUser by remember(s.id) { mutableStateOf(false) }      // used when Autoplay is off
    var menu by remember { mutableStateOf(false) }
    var expanded by remember(s.id) { mutableStateOf(false) }
    var captionCut by remember(s.id) { mutableStateOf(false) }
    val mayPlay = autoplay || startedByUser
    val url = (if (dataSaver) s.videoUrlLow else s.videoUrl) ?: s.videoUrl

    // Step 75 (plan v4.0.1): deleted / hidden / no longer allowed: a clear message, no picture, no player, no actions.
    if (blocked) {
        Box(Modifier.fillMaxSize().background(MediaBackdrop), contentAlignment = Alignment.Center) {
            Column(Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.VideocamOff, null, tint = Color.White.copy(.8f), modifier = Modifier.size(44.dp))
                Spacer(Modifier.height(12.dp))
                Text(tr("short_unavailable"), color = Color.White, fontSize = 15.sp, textAlign = TextAlign.Center)
            }
        }
        return
    }

    // Step 75: the full-screen player waits for the server's answer about THIS video before it shows a picture or plays (usually instant)
    if (holding) {
        Box(Modifier.fillMaxSize().background(MediaBackdrop), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
        return
    }

    Box(
        Modifier.fillMaxSize().pointerInput(s.id, mayPlay, s.liked) {
            detectTapGestures(
                onDoubleTap = { if (!s.liked) onLike() },
                onTap = { if (mayPlay) paused = !paused else startedByUser = true }
            )
        }
    ) {
        s.posterUrl?.let { AsyncImage(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
        if (active && mayPlay && url != null) ShortPlayer(url, playing = !paused, Modifier.fillMaxSize(), onWatched = onWatched)

        if (!mayPlay || paused) {
            Box(Modifier.align(Alignment.Center).size(72.dp).clip(CircleShape).background(MediaGlass),
                contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.PlayArrow, tr("a11y_play"), tint = Color.White, modifier = Modifier.size(40.dp))
            }
        }

        // dark scrim so text stays readable on any video
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.6f to Color.Transparent, 1f to Color(0xCC000000))))

        // right action rail (new design): the author's photo with a purple "+" (follow), heart, comments, save, share, more
        Column(
            Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 16.dp + clearance),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(contentAlignment = Alignment.BottomCenter) {
                Box(Modifier.clip(CircleShape).then(if (onProfile != null) Modifier.clickable(onClick = onProfile) else Modifier)
                    .border(2.dp, Color.White, CircleShape).padding(2.dp)) { Avatar(s.avatarUrl, 44) }
                if (s.followStatus == "none") {
                    Box(
                        Modifier.offset(y = 9.dp).size(22.dp).clip(CircleShape).background(Accent).clickable(onClick = onFollow),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Add, tr("follow"), tint = OnAccent, modifier = Modifier.size(15.dp)) }
                }
            }
            Spacer(Modifier.height(4.dp))
            Rail(if (s.liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, compactCount(s.likeCount),
                if (s.liked) LikeRed else Color.White, onLike)
            Rail(Icons.Outlined.ChatBubbleOutline, if (s.commentsEnabled) compactCount(s.commentCount) else "Off",
                Color.White, onComments)
            Rail(if (s.saved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder, compactCount(s.saveCount),
                Color.White, onSave)
            Rail(Icons.Filled.Share, "", Color.White) {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${s.username} on Sociax: ${s.caption}")
                }
                onShared()
                context.startActivity(Intent.createChooser(send, "Share"))
            }
            Box {
                Rail(Icons.Filled.MoreHoriz, "", Color.White) { menu = true }
                DropdownMenu(menu, { menu = false }) {
                    if (s.mine) DropdownMenuItem(text = { Text(tr("delete_video")) }, onClick = { menu = false; onDelete() })
                    else {
                        DropdownMenuItem(text = { Text(tr("not_interested")) }, onClick = { menu = false; onNotInterested() })
                        DropdownMenuItem(text = { Text(tr("hide_creator")) }, onClick = { menu = false; onHideCreator() })
                        listOf("Spam", "Harassment", "Inappropriate content").forEach { r ->
                            DropdownMenuItem(text = { Text(trf("report_fmt", reasonLabel(r))) }, onClick = { menu = false; onReport(r) })
                        }
                    }
                }
            }
        }

        // bottom-left: author name, time, caption, emoji reactions
        // (bottom padding leaves room for the docked tab bar)
        Column(Modifier.align(Alignment.BottomStart).padding(start = 14.dp, end = 76.dp, bottom = 10.dp + clearance)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(s.username, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false).then(if (onProfile != null) Modifier.clickable(onClick = onProfile) else Modifier))
                Spacer(Modifier.width(8.dp))
                Text(timeAgo(s.createdAt) + if (s.audience == "followers") " · Followers" else "",
                    color = Color.White.copy(.7f), fontSize = 12.sp, maxLines = 1)
                when (s.followStatus) {
                    "pending" -> { Spacer(Modifier.width(8.dp)); SmallChip(tr("requested"), onFollow, active = false) }
                    "self", "none" -> {}
                    else -> { Spacer(Modifier.width(8.dp)); SmallChip(tr("following"), onFollow, active = false) }
                }
            }
            if (s.caption.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    s.caption, color = Color.White.copy(.92f), fontSize = 14.sp,
                    maxLines = if (expanded) Int.MAX_VALUE else 2, overflow = TextOverflow.Ellipsis,
                    onTextLayout = { if (!expanded) captionCut = it.hasVisualOverflow }
                )
                if (captionCut || expanded) {
                    Text(
                        if (expanded) tr("show_less") else tr("read_more"),
                        color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                        modifier = Modifier.clickable { expanded = !expanded }
                    )
                }
            }
            // emoji reactions 😮 😂 😢 with counts (the heart is in the right rail)
            Spacer(Modifier.height(10.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                REACTION_KINDS.forEach { (kind, emoji) ->
                    val r = s.reactions[kind] ?: React()
                    EmojiChip(emoji, r.count, r.mine, onMedia = true) { onReact(kind) }
                }
            }
        }
    }
}

@Composable
private fun Rail(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, tint: Color, onClick: () -> Unit) {
    // reference: plain white outline icons with the number underneath, no circle behind them
    Column(Modifier.clickable(onClick = onClick).padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(30.dp))
        if (label.isNotEmpty()) Text(label, color = Color.White, fontSize = 12.sp)
    }
}

/** Step 40: plain counters for one video on screen: milliseconds really played, and whether it got to the end (90 %). */
private class WatchStats { var ms = 0L; var done = false }

/** One ExoPlayer, only for the video currently on screen (saves memory and data). Loops. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
private fun ShortPlayer(url: String, playing: Boolean, modifier: Modifier = Modifier, onWatched: ((Long, Boolean) -> Unit)? = null) {
    val context = LocalContext.current
    val exo = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url)); repeatMode = Player.REPEAT_MODE_ONE; prepare()
        }
    }
    // Step 40: how long this video REALLY played and whether it reached (nearly) the end. Reported once, when it leaves the screen.
    val stats = remember(exo) { WatchStats() }
    val watchedCallback by rememberUpdatedState(onWatched)
    DisposableEffect(exo) { onDispose { watchedCallback?.invoke(stats.ms, stats.done); exo.release() } }

    // pause when the app goes to the background
    val owner = LocalLifecycleOwner.current
    var resumed by remember { mutableStateOf(true) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) resumed = false else if (e == Lifecycle.Event.ON_RESUME) resumed = true
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(playing, resumed, exo) { exo.playWhenReady = playing && resumed }

    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(exo) {
        var last = android.os.SystemClock.elapsedRealtime()
        while (true) {
            val now = android.os.SystemClock.elapsedRealtime()
            if (exo.isPlaying) stats.ms += (now - last).coerceIn(0L, 1000L)
            last = now
            val d = exo.duration
            progress = if (d > 0) (exo.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
            if (progress >= 0.9f) stats.done = true
            delay(250)
        }
    }

    Box(modifier) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = exo; useController = false
                    setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)   // poster stays visible until the first frame
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        LinearProgressIndicator(
            progress = { progress }, color = Accent, trackColor = Color.White.copy(.2f),
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp)
        )
    }
}

/** Plays a local clip (optionally only start..end) in a loop: used for the pre-publish preview. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
private fun ClipPreview(uri: Uri, startMs: Long, endMs: Long?, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val exo = remember { ExoPlayer.Builder(context).build().apply { repeatMode = Player.REPEAT_MODE_ALL } }
    DisposableEffect(exo) { onDispose { exo.release() } }
    LaunchedEffect(uri, startMs, endMs) {
        val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs).apply {
            if (endMs != null) setEndPositionMs(endMs)
        }.build()
        exo.setMediaItem(MediaItem.Builder().setUri(uri).setClippingConfiguration(clip).build())
        exo.prepare(); exo.playWhenReady = true
    }
    AndroidView(factory = { c -> PlayerView(c).apply { player = exo; useController = false } }, modifier = modifier)
}

// =====================================================================
// Create a short: pick / record -> compress -> preview -> publish
// Plan v3.9.1: there is NO duration limit and the length is never required. The video is never trimmed or shortened
// by the app UNLESS the person chooses it in the video editor (Step 78): skipping the editor keeps the exact old path.
// The only checks are file size, file type, login and the daily media quota (all on the server).
// =====================================================================
private enum class CStage { Pick, Working, Edit, Preview, Uploading }

private class CaptureShort : ActivityResultContract<Uri, Boolean>() {
    override fun createIntent(context: Context, input: Uri): Intent =
        Intent(MediaStore.ACTION_VIDEO_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, input)                   // no EXTRA_DURATION_LIMIT: the camera records as long as the person wants
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
    override fun parseResult(resultCode: Int, intent: Intent?) = resultCode == Activity.RESULT_OK
}

/** h:mm:ss from one hour on, m:ss below. Only used to DISPLAY a length that was read; an unknown length shows nothing. */
private fun mmss(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun CreateShortScreen(api: ApiClient, onBack: () -> Unit, onPosted: () -> Unit, defaultFollowersOnly: Boolean = false) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { Prefs(context) }

    var stage by remember { mutableStateOf(CStage.Pick) }
    var prepared by remember { mutableStateOf<File?>(null) }
    var preparedMs by remember { mutableLongStateOf(0L) }            // 0 = length unknown (display only, never sent and never a limit)
    var caption by remember { mutableStateOf("") }
    var followersOnly by remember { mutableStateOf(defaultFollowersOnly) }
    var commentsOn by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val errRead = tr("err_read_video")
    val errEdit = tr("err_video_edit")
    // Step 78: the picked video, what was read from it and what the person chose in the editor (kept while they go back and forth)
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var source by remember { mutableStateOf<VideoSource?>(null) }
    var edits by remember { mutableStateOf(VideoEdits()) }
    var pendingCamera by remember { mutableStateOf<Uri?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    // Step 35: a clip already uploaded to Cloudinary (prepared file path -> public id): "try again" re-sends only the record
    var uploadedClip by remember { mutableStateOf<Pair<String, String>?>(null) }

    DisposableEffect(Unit) { onDispose { prepared?.delete() } }

    fun launchStep(block: suspend () -> Unit) { job?.cancel(); job = scope.launch { block() } }

    /** Compresses the whole video (never cuts it), then shows the preview. */
    suspend fun prepare(uri: Uri) {
        stage = CStage.Working; error = null
        prepared?.delete(); prepared = null
        try {
            prepared = exportShort(context, uri, 0L, null, prefs.uploadQuality)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // compressing is not possible on this phone / for this file: publish the original, unchanged
            try { prepared = copyVideoToCache(context, uri) } catch (e2: CancellationException) { throw e2 } catch (e2: Exception) {
                error = errRead; stage = CStage.Pick; return
            }
        }
        val f = prepared!!
        // Plan v3.9.1: the length is OPTIONAL. It is read only to show it in the preview; if it cannot be read, nothing is blocked,
        // nothing is invented (0 = unknown) and the problem is only written to the log (VideoUtils).
        preparedMs = withContext(Dispatchers.IO) { try { videoDurationMs(context, Uri.fromFile(f)) } catch (e: Exception) { 0L } }.coerceAtLeast(0L)
        stage = CStage.Preview
    }

    /** Step 78: the edited video: trim / turn / crop / filter by Media3 + the native engine, checked before it is accepted. The edits stay on a failure. */
    suspend fun prepareEdited(uri: Uri, s: VideoSource, e: VideoEdits) {
        stage = CStage.Working; error = null
        prepared?.delete(); prepared = null
        try {
            prepared = exportEdited(context, uri, e, s, prefs.uploadQuality)
        } catch (ex: CancellationException) {
            throw ex
        } catch (ex: Exception) {
            // the original is untouched and the edits are kept: the person can change them and try again, or go back and post without editing
            Log.w("SociaxVideoEdit", "edited export failed (${ex.javaClass.simpleName})")
            error = errEdit; stage = CStage.Edit
            return
        }
        val f = prepared!!
        preparedMs = withContext(Dispatchers.IO) { try { videoDurationMs(context, Uri.fromFile(f)) } catch (ex: Exception) { 0L } }.coerceAtLeast(0L)
        stage = CStage.Preview
    }

    // Plan v3.9.1: picking a video does NOT block on its length. Step 78: when size and length ARE readable the editor opens first;
    // when they are not, the video goes straight on exactly as before (the editor is never a gate).
    fun onPicked(uri: Uri) = launchStep {
        stage = CStage.Working; error = null
        val s = try { readVideoSource(context, uri) } catch (e: CancellationException) { throw e } catch (e: Exception) { null }
        if (s == null) {
            pickedUri = null; source = null
            prepare(uri)
        } else {
            pickedUri = uri; source = s; edits = VideoEdits()
            stage = CStage.Edit
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u -> if (u != null) onPicked(u) }
    val camera = rememberLauncherForActivityResult(remember { CaptureShort() }) { ok ->
        val u = pendingCamera
        if (ok && u != null) onPicked(u)
    }

    fun publish() {
        val f = prepared ?: return
        launchStep {
            stage = CStage.Uploading; error = null
            try {
                val publicId = uploadedClip?.takeIf { it.first == f.absolutePath }?.second ?: run {
                    val sig = api.signUpload("short", f.length().coerceAtMost(Int.MAX_VALUE.toLong()).toInt())   // no wrap-around for a huge file: the server then says "too big"
                    api.uploadVideoToCloudinary(sig, f)
                    uploadedClip = f.absolutePath to sig.publicId
                    sig.publicId
                }
                // "Published" only after the server saved the clip record (onPosted runs after createShort returns)
                api.createShort(publicId, caption.trim(), if (followersOnly) "followers" else "public", commentsOn)
                uploadedClip = null
                onPosted()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // the server deletes a refused clip, so after a permanent refusal the next try must upload again
                if (e is ApiException && e.code in 400..499 && e.reason != "media_full" && e.code != 429) uploadedClip = null
                error = msg(e); stage = CStage.Preview
            }
            Unit
        }
    }

    // Back: step back inside this flow first; leave only from the first step.
    // (the editor stage has its own back handling and its own "discard edits?" question)
    BackHandler(enabled = stage != CStage.Pick && stage != CStage.Edit) {
        job?.cancel()
        if (stage == CStage.Preview) { prepared?.delete(); prepared = null }
        stage = if (stage != CStage.Uploading && source != null) CStage.Edit else CStage.Pick
    }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp)) {
        TopBar(tr("new_short"), onBack)

        when (stage) {
            CStage.Pick -> {
                GlassPanel(Modifier.fillMaxWidth().height(260.dp), corner = 28) {
                    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center) {
                        Icon(Icons.Filled.VideoLibrary, null, tint = Accent, modifier = Modifier.size(52.dp))
                        Spacer(Modifier.height(10.dp))
                        Text(tr("choose_record"), color = Ink, fontWeight = FontWeight.SemiBold)
                        Text(tr("max_len_note"),
                            color = Ink.copy(.65f), fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Spacer(Modifier.height(16.dp))
                PillButton(tr("choose_gallery"), {
                    gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                PillButton(tr("record_camera"), {
                    val dir = File(context.cacheDir, "camera").apply { mkdirs() }
                    val f = File(dir, "rec_${System.currentTimeMillis()}.mp4")
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
                    pendingCamera = uri
                    camera.launch(uri)
                }, Modifier.fillMaxWidth(), filled = false)
                error?.let { Text(it, color = ErrorInk, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp)) }
                Spacer(Modifier.height(10.dp))
                Text(trf("quality_line", when (prefs.uploadQuality) { "low" -> tr("ql_low"); "high" -> tr("ql_high"); else -> tr("ql_std") }), color = Ink.copy(.55f), fontSize = 12.sp)
            }

            CStage.Edit -> Unit      // drawn on top of this column below (full screen, dark)

            CStage.Working, CStage.Uploading -> {
                Column(Modifier.fillMaxWidth().padding(top = 80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Accent)
                    Spacer(Modifier.height(16.dp))
                    Text(if (stage == CStage.Working) tr("preparing") else tr("uploading"),
                        color = Ink)
                    Spacer(Modifier.height(20.dp))
                    PillButton(tr("cancel"), { job?.cancel(); stage = if (stage == CStage.Uploading) CStage.Preview else if (source != null) CStage.Edit else CStage.Pick }, filled = false)
                }
            }

            CStage.Preview -> {
                val f = prepared
                Text(tr("preview"), color = Accent, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                GlassPanel(Modifier.fillMaxWidth().height(380.dp), corner = 28) {
                    if (f != null) ClipPreview(Uri.fromFile(f), 0, null, Modifier.fillMaxSize())
                }
                if (f != null) Text(
                    // an unknown length is simply not shown (plan v3.9.1: never a made-up 0:00)
                    (if (preparedMs > 0) "${mmss(preparedMs)} · " else "") + "${"%.1f".format(f.length() / 1048576.0)} MB",
                    color = Ink.copy(.65f), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(12.dp))
                GlassField(caption, { caption = it.take(2200) }, tr("write_caption"))
                Spacer(Modifier.height(12.dp))
                Text(tr("who_can_watch"), color = Accent, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton(tr("public"), { followersOnly = false }, filled = !followersOnly)
                    PillButton(tr("followers_only"), { followersOnly = true }, filled = followersOnly)
                }
                Spacer(Modifier.height(12.dp))
                Text(tr("comments"), color = Accent, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton(tr("on"), { commentsOn = true }, filled = commentsOn)
                    PillButton(tr("off"), { commentsOn = false }, filled = !commentsOn)
                }
                error?.let { Text(it, color = ErrorInk, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)) }
                Spacer(Modifier.height(18.dp))
                PillButton(tr("publish"), { publish() }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                PillButton(tr("choose_another"), { prepared?.delete(); prepared = null; source = null; pickedUri = null; stage = CStage.Pick },
                    Modifier.fillMaxWidth(), filled = false)
            }
        }
    }

    // Step 78: the video editor (full screen, dark) over the page while stage is Edit
    val editUri = pickedUri
    val editSource = source
    if (stage == CStage.Edit && editUri != null && editSource != null) {
        VideoEditorScreen(
            editUri, editSource, edits, error,
            onCancel = { source = null; pickedUri = null; error = null; stage = CStage.Pick },
            onDone = { e ->
                edits = e
                launchStep { if (e.isDefault) prepare(editUri) else prepareEdited(editUri, editSource, e) }
            }
        )
    }
    }   // Box
}

// =====================================================================
// Comments for a short (same screen as post comments)
// =====================================================================
@Composable
fun ShortCommentsScreen(api: ApiClient, short: ShortVideo, onBack: () -> Unit, onChanged: () -> Unit) {
    CommentsScaffold(
        load = { api.shortComments(short.id) },
        send = { api.addShortComment(short.id, it) },
        onBack = onBack, onChanged = onChanged, key = "s${short.id}"
    )
}


// =====================================================================
// Step 21: Settings > Privacy & Security > Saved short videos
// =====================================================================
/** Short videos I saved (bookmark), as a grid of first-frame thumbnails; tap one to watch it full-screen. */
@Composable
fun SavedShortsScreen(api: ApiClient, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var shorts by remember { mutableStateOf<List<ShortVideo>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var more by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var watching by remember { mutableStateOf<ShortVideo?>(null) }
    val pageSize = 30

    LaunchedEffect(Unit) {
        try { shorts = api.savedShorts(); more = shorts.size >= pageSize }
        catch (e: CancellationException) { throw e } catch (e: Exception) { error = msg(e) }
        loading = false
    }

    val current = watching
    if (current != null) {
        BackHandler { watching = null }
        SavedShortPlayer(
            s = current, dataSaver = Prefs(LocalContext.current).dataSaver,
            onClose = { watching = null },
            onUnsave = {
                scope.launch {
                    try { api.setShortBookmark(current.id, false); shorts = shorts.filter { it.id != current.id }; watching = null }
                    catch (e: CancellationException) { throw e } catch (e: Exception) { error = msg(e); watching = null }
                }
            }
        )
        return
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp)) {
        TopBar(tr("saved_shorts"), onBack)
        error?.let { Text(it, color = ErrorInk, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp)) }
        if (loading) CircularProgressIndicator(color = Accent)
        else if (shorts.isEmpty()) Text(tr("no_saved_shorts"), color = Ink.copy(.7f))
        else {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                shorts.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        row.forEach { sv ->
                            Box(
                                Modifier.weight(1f).aspectRatio(0.6f).clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                                    .background(FieldFill).clickable { watching = sv }
                            ) {
                                sv.posterUrl?.let { coil.compose.AsyncImage(it, sv.caption, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop) }
                                Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.align(Alignment.Center).size(32.dp))
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            if (more) {
                Spacer(Modifier.height(12.dp))
                PillButton(tr("load_more"), {
                    scope.launch {
                        try {
                            val next = api.savedShorts(before = shorts.last().id)
                            shorts = shorts + next.filter { n -> shorts.none { it.id == n.id } }; more = next.size >= pageSize
                        } catch (e: CancellationException) { throw e } catch (e: Exception) { error = msg(e) }
                    }
                }, filled = false)
            }
            Spacer(Modifier.height(10.dp))
            Text(tr("saved_shorts_note"), color = Ink.copy(.5f), fontSize = 12.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** Full-screen playback of one saved clip with close and "remove from saved" buttons. */
@Composable
private fun SavedShortPlayer(s: ShortVideo, dataSaver: Boolean, onClose: () -> Unit, onUnsave: () -> Unit) {
    val url = (if (dataSaver) s.videoUrlLow else s.videoUrl) ?: s.videoUrl
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (url != null) ShortPlayer(url, playing = true, modifier = Modifier.fillMaxSize())
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassIconButton(Icons.Filled.ArrowBack, tr("a11y_back"), onClose, onMedia = true)
            Spacer(Modifier.weight(1f))
            PillButton(tr("remove_saved"), onUnsave, filled = false)
        }
        Column(Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(16.dp)) {
            Text(s.username, color = Color.White, fontWeight = FontWeight.Bold)
            if (s.caption.isNotBlank()) Text(s.caption, color = Color.White.copy(.9f), fontSize = 14.sp, maxLines = 3)
        }
    }
}

/** Step 26: full-screen playback of one clip opened from Search (back button only). */
@Composable
fun SearchShortPlayer(s: ShortVideo, dataSaver: Boolean, onClose: () -> Unit) {
    val url = (if (dataSaver) s.videoUrlLow else s.videoUrl) ?: s.videoUrl
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (url != null) ShortPlayer(url, playing = true, modifier = Modifier.fillMaxSize())
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassIconButton(Icons.Filled.ArrowBack, tr("a11y_back"), onClose, onMedia = true)
        }
        Column(Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(16.dp)) {
            Text(s.username, color = Color.White, fontWeight = FontWeight.Bold)
            if (s.caption.isNotBlank()) Text(s.caption, color = Color.White.copy(.9f), fontSize = 14.sp, maxLines = 3)
        }
    }
}
